<?php
define('BASE_URL', '/portfolio'); 